# S034 adversarial obligations — RUNNING

Full fresh271+retained/fresh K9 smoke and full native/mapping/rules acceptance
passed. Scheduler controls reject duplicate claims and wrong tokens, compare
all512 small graph assignments to exact weights, run two tiny native workers,
reject damaged DRAT, require a live native deadline stop, and kill/restart a
controller with nonempty independently audited recovered cuts. This does not
justify two full phone workers; concurrency remains one.

No region closes from bare UNSAT, a partial proof, timeout, log counter, stale
PID or controller crash. Source/input/native hashes and claim tokens are bound
to each attempt. Extra journals are complete-prefix hashed and independently
checked subdivisions before reuse. A final whole-domain/stratum claim requires
separate review. Native SAT is independently checked but remains pending domain
review. Historical cell128 baseline closure is not learned-rule effectiveness.

No thermal/PSI visibility; Android may kill the environment. A guardian cannot
survive a complete Android kill or power loss. Deadline and resource limits are
independently checked in the guardian/controller; native has an absolute UTC
hook. Priority is lowered. Device safety overrides continued computation.
