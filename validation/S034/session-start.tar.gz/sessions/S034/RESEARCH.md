# S034 research — IN PROGRESS

CAM-0039 executes original S11 exact graph-prefix regions with guarded native
partial planarity. Real cell0 started2026-10-21T20:52:22.847406Z after full
fresh phone verification and scheduler controls. UNKNOWN regions requeue;
the user deadline is2026-10-22T06:00:00Z. No scientific conclusion is implied
by this running record. Read the live ledger for actual progress.

One native worker, atomic unique claims, complete-prefix geometric checkpoints,
independent clause reuse audit, exact standalone CaDiCaL/DRAT region closure,
and separate guardian crash/deadline enforcement. Private CDCL state is lost
between visits. No256 copies of190MB: derived input/formula files are recreated
from hash-pinned recipe/source blocks and removed after their hashes are saved.
Proofs, logs and semantic journals remain. All archived S032/S033 bytes preserved.
