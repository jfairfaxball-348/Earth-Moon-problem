"""Portable S034 running-record integrity; never native/proof replay or CI science."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tools'))
from s034_regions import validate_partition

def read(name):
    return json.loads((ROOT/name).read_text())

manifest = read('sessions/S034/RUNNING_MANIFEST.json')
for name, row in manifest['files'].items():
    p = ROOT/name
    assert p.stat().st_size == row['bytes'], name
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256'], name
smoke = read('validation/S034/SMOKE.json')
native = read('validation/S034/NATIVE_CONTROLS.json')
audit = read('validation/S034/INPUT_AUDIT.json')
controls = read('validation/S034/SCHEDULER_CONTROLS.json')
config = read('validation/S034/REGISTERED_CONFIG.json')
assert smoke['verdict'] == 'PASS'
assert smoke['chromatic_rows_verified'] == smoke['chromatic_cnf_byte_matches'] == 271
assert smoke['k9']['verified'] and smoke['solver_roundtrip']['fresh_proof_verified']
assert native['exhaustive_n5_fixed_graphs'] == 1024 and native['K33'] == native['positive24'] == 'PASS'
assert native['free_K9'] == 'UNKNOWN_AT_2S'
assert native['native_sha256'] == controls['native_sha256'] == config['native_sha256']
assert controls['status'] == 'PASS' and controls['exact_small_graph_assignments'] == 512
assert controls['controller_kill_restart'] == 'PASS' and controls['damaged_proof_rejected']
assert controls['native_absolute_deadline'] == controls['guardian_deadline'] == 'PASS_UNKNOWN'
assert audit['status'] == 'PASS' and audit['bijective_renaming_checked']
assert audit['independently_checked_native_clauses'] == 2579937
assert audit['lemma_sha256'] == config['seed']['sha256'] == '6e6d88e19e3526117b1a01ea0a7f818ec7c8f950e3c379fdb380d096b10c7177'
assert config['variables'] == 17976 and config['base_clauses'] == 336030
assert config['deadline'] == read('docs/D073_S034_OVERNIGHT_AUTHORIZATION.json')['deadline_epoch'] == 1792648800
assert config['workers'] == 1 and not config['concurrency_increase_validated']
assert config['bits'] == 8
# Independently reconstruct the entire assumption/weight partition from pinned registration.
import itertools
import math
units = {int(k): v for k, v in config['graph_units'].items()}
free = [v for v in config['graph_variables'] if v not in units]
cells = []
for i, values in enumerate(itertools.product((False, True), repeat=8)):
    present = sum(units.values())+sum(values)
    count = sum(math.comb(len(free)-8, m-present) for m in (155, 156)
                if 0 <= m-present <= len(free)-8)
    cells.append(dict(id=i, assumptions=[v if b else -v for v, b in zip(free[:8], values)], weight=str(count)))
assert validate_partition(config, cells)
with tarfile.open(ROOT/'validation/S034/native.tar.gz') as archive:
    assert hashlib.sha256(archive.extractfile('native/bipsat_s034').read()).hexdigest() == config['native_sha256']
    source = archive.extractfile('native/bipsat_s032.cpp').read().decode()
    assert 'EMP_ABSOLUTE_DEADLINE' in source and source.count('S032 independent subdivision guard') == 2
state = read('authoritative/STATE.json')
if state.get('active_session', {}).get('id') == 'S034':
    assert state['last_completed_session'] == 'S033' and state['active_session']['status'] == 'RUNNING'
    assert state['next_session_is_future_unexecuted'] is False
    for name, digest in controls['source_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest
assert (ROOT/'sessions/S034/EXECUTED_PROMPT.md').read_bytes() == (ROOT/'sessions/S033/S034_FUTURE_PROMPT.md').read_bytes()
print('PASS S034 registered256-region partition, fresh phone gates and immutable running evidence; not a closeout or new mathematical claim')
