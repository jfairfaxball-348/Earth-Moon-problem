# Third-party components

Vendored unmodified, each under its own licence in its directory:

- **CaDiCaL 2.1.3** (`third_party/cadical`), Armin Biere; tag rel-2.1.3, commit f13d74439a5b5c963ac5b02d05ce93a8098018b8 of https://github.com/arminbiere/cadical; MIT licence. bipsat2 drives it through the IPASIR-UP ExternalPropagator interface.
- **Edge Addition Planarity Suite 4.0.1** (`third_party/edge-addition-planarity-suite`), John M. Boyer; tag Version_4.0.1.0, commit c10f90f2d79fdb07a797a625a89ef70e23a1eb2c of https://github.com/graph-algorithms/edge-addition-planarity-suite; licence in `LICENSE.TXT`. Used for Boyer–Myrvold planarity testing and Kuratowski subgraph extraction.
- **drat-trim** (`third_party/drat-trim/drat-trim.c`), Marijn Heule and Nathan Wetzler; MIT licence. Used by `tools/replay.py` to check DRAT proofs.

The design of a planarity propagator returning Kuratowski subgraphs as clauses follows M. Kirchweger, M. Scheucher and S. Szeider, "SAT-based generation of planar graphs", SAT 2023.
