# Formats and command line

## Instance file

```
p bipsat2 <n> <m> <n_extra_vars> <n_extra_clauses>
e <u> <v>              m lines, 0-based vertices; edge i is the i-th of these lines (0-based)
<lit> ... 0            n_extra_clauses DIMACS clauses
```

Edge i has two Boolean variables: `2i+1` means "edge i is in layer 1", `2i+2` means "edge i is in layer 2". Both false means the edge is absent, both true is allowed. Extra variables `2m+1 .. 2m+n_extra_vars` are free for encodings (cardinality counters, triangle indicators, lex-leader chains).

To decide biplanarity of a fixed graph, the clauses must say each edge is in exactly one layer: `(2i+1 ∨ 2i+2)` and `(¬(2i+1) ∨ ¬(2i+2))` for every i. `encoder/encode.py` writes those together with exact layer sizes, the face rules and twin lex-leaders. Leaving an edge unconstrained makes it optional, which turns the instance into a synthesis search: the solver chooses which edges exist as well as how they split.

## Solver

```
bipsat2 <instance> [--timeout SECONDS] [--lemmas FILE] [--validate-lemmas-only] [--write-validated-lemmas FILE]
                   [--enumerate N] [--block-vars FIRST COUNT]
```

The propagator watches the partial assignment inside CaDiCaL; whenever a layer's currently assigned edge set is nonplanar it extracts a Kuratowski subgraph (Boyer–Myrvold) and adds the clause "not all of these edges in this layer". A full model is accepted only after both layers pass a from-scratch planarity check.

Output: `s SATISFIABLE`, `s UNSATISFIABLE` or `s UNKNOWN` (timeout); on SAT, lines `L1 u-v ...` and `L2 u-v ...` give the verified split; statistics lines start with `c ` (`c checks=... nonplanar=... clauses_added=... model_checks=...`). Exit codes: 10 SAT, 20 UNSAT, 0 UNKNOWN.

`--lemmas FILE` persists every learned Kuratowski clause to FILE (appended, flushed every 1,024 lemmas) and, if FILE exists, reloads it first: each reloaded lemma is re-derived as a nonplanar edge set before it is admitted. A run that is stopped, crashes, hits its cap or moves to another machine keeps its geometric knowledge; the next run starts with it. `--validate-lemmas-only` re-checks a lemma file and exits; `--write-validated-lemmas` writes the accepted subset.

## Lemma file

One clause per line, DIMACS style, `0` terminated: negative literals of the layer variables of the edges of one Kuratowski subgraph, all in the same layer. Lemma files are instance-specific through the edge order; the same edge order with different extra clauses (another split, extra symmetry breaking) can reuse them, which is how passes with increasing caps resume.

## Replay and certification

`tools/replay.py <instance> <lemma file>` validates every lemma (negative literals, one layer, nonplanar edge set), writes the base clauses plus the lemmas as plain DIMACS, runs CaDiCaL on it with a DRAT proof, and runs drat-trim on the proof. The verdict is `UNSAT_CERTIFIED` only when CaDiCaL refutes the plain CNF and drat-trim prints `s VERIFIED`. A JSON receipt with counts and the SHA256 of the CNF and proof is written next to the instance. `tools/kuratowski_strict.py <instance> <lemma file>` is an independent, stricter check that each lemma's edges form an exact subdivision of K5 or K3,3.
