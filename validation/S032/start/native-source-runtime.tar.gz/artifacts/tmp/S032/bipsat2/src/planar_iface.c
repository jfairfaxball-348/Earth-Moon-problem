#include "planar_iface.h"
#include "graphLib.h"
#include <stdlib.h>

struct PlanCtx {
  graphP g;
  int n;
};

PlanCtx *plan_new (int n, int max_edges) {
  PlanCtx *ctx = (PlanCtx *) malloc (sizeof (PlanCtx));
  if (!ctx) return NULL;
  ctx->n = n;
  ctx->g = gp_New ();
  if (!ctx->g) { free (ctx); return NULL; }
  if (gp_EnsureArcCapacity (ctx->g, 2 * (max_edges + 4)) != OK ||
      gp_InitGraph (ctx->g, n) != OK) {
    gp_Free (&ctx->g);
    free (ctx);
    return NULL;
  }
  return ctx;
}

void plan_free (PlanCtx *ctx) {
  if (!ctx) return;
  if (ctx->g) gp_Free (&ctx->g);
  free (ctx);
}

int plan_check (PlanCtx *ctx, const int *edges, int k, int *kur, int *kur_len) {
  graphP g = ctx->g;
  int first, i, v, e, w, result, cnt;

  gp_ReinitializeGraph (g);
  first = gp_GetFirstVertex (g);
  for (i = 0; i < k; i++) {
    if (gp_AddEdge (g, first + edges[2 * i], 0, first + edges[2 * i + 1], 0) != OK)
      return -1;
  }
  result = gp_Embed (g, EMBEDFLAGS_PLANAR);
  if (result == OK) return 1;
  if (result != NONEMBEDDABLE) return -1;
  if (gp_SortVertices (g) != OK) return -1;

  cnt = 0;
  for (v = first; v < first + ctx->n; v++) {
    for (e = gp_GetFirstArc (g, v); gp_IsArc (e); e = gp_GetNextArc (g, e)) {
      w = gp_GetNeighbor (g, e);
      if (v < w) {
        kur[2 * cnt] = v - first;
        kur[2 * cnt + 1] = w - first;
        cnt++;
      }
    }
  }
  *kur_len = cnt;
  if (cnt < 9) return -1; /* K3,3 has 9 edges; anything smaller is a bug */
  return 0;
}
