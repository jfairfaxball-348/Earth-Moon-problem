# The exact-split encoding

`encoder/encode.py` writes one instance per admissible pair of layer sizes. For m edges on n vertices the pairs are (e1, e2) with e1 + e2 = m, e1 ≥ e2 and e1 ≤ 3n − 6, since each planar layer holds at most 3n − 6 edges. Both layer sizes are fixed with exact cardinality constraints (sequential counters), and when e1 = e2 the layer swap is pinned by putting edge 0 in layer 2.

## Face rules from the Euler deficit

Write e1 = 3n − 6 − d. A simple planar graph with that many edges on n vertices has face-length excess Σ_f (len(f) − 3) = d − 3(c − 1) ≤ d, where c is the number of components and faces are boundary walks. Hence, for the layer:

- **d = 0.** A triangulation: every vertex has layer-degree at least 3 and every layer edge lies on two layer-triangles.
- **d = 1.** Connected (a second component would cost at least three edges of excess) and bridgeless (a bridge forces a face walk of length at least 5), so every vertex has layer-degree at least 2, every layer edge lies on at least one layer-triangle, and all but at most four layer edges lie on two.
- **General d.** An edge bordering triangular faces on both sides lies on two distinct layer-triangles, and the edges touching non-triangular faces number at most Σ len(f) over those faces, which is at most 4d. So at most 4d layer edges lie on fewer than two layer-triangles.

The encoding introduces one indicator variable per (triangle of the graph, layer), equivalent to the conjunction of its three edges' layer variables, and expresses the rules as cardinality constraints over each edge's triangle indicators, guarded by the edge's layer variable; the general-d rule uses one exception variable per edge with "at most 4d exceptions". The "faces are cycles" reading is used only for d ≤ 1.

## Twin lex-leaders

Two vertices are closed twins when they are adjacent with the same closed neighbourhood, false twins when they are non-adjacent with the same open neighbourhood. Swapping twins is an automorphism, so for each twin pair (a, b) the encoding adds a lex-leader chain forcing the vector of a's edge-layer variables (over the common neighbours, in vertex order) to be lexicographically at most b's; for a twin class the chains together sort the class and remove its whole symmetric group. The chains are compatible with the swap pin: the lexicographically smallest element of an orbit under twin swaps and the layer swap has edge 0 in layer 2 and satisfies every chain.

Effect, measured on K7 ∨ I3 (ten vertices, 42 edges, 30,240 automorphisms, non-biplanar): with chains for its 24 twin pairs the four splits are refuted in 1, 3, 4 and 3 seconds; the same instances without the chains do not finish in 300 seconds.
