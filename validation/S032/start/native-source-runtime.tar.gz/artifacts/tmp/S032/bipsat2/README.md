# bipsat2

SAT modulo planarity for deciding whether a graph is **biplanar** (its edges split into two planar layers), built for the Earth–Moon problem: does a biplanar graph with chromatic number 10 exist?

bipsat2 is CaDiCaL with an external propagator. One Boolean variable says which layer an edge is in; the propagator runs Boyer–Myrvold planarity on each layer's partial edge set and, when a layer goes nonplanar, returns the Kuratowski subgraph as a clause. Three things make it usable on dense instances that short runs cannot decide:

1. **Persistent lemmas.** Every learned Kuratowski clause is written to a file and revalidated on reload, so a run that is stopped, crashes, hits its cap or moves between machines keeps its geometric knowledge. Multi-day attacks on one instance are routine.
2. **Exact layer sizes with Euler-deficit face rules.** One instance per admissible (e1, e2); a layer d edges below a triangulation gets degree, triangle-incidence and "at most 4d exceptional edges" constraints. See `docs/ENCODING.md`.
3. **Twin lex-leaders.** Closed and false twins are sorted by lex-leader chains. On K7 ∨ I3 (30,240 automorphisms) this turns four 300-second timeouts into refutations of 1 to 4 seconds.

Native UNSAT verdicts are certifiable: `tools/replay.py` rebuilds the base clauses plus the validated lemmas as plain DIMACS, refutes it with CaDiCaL under a DRAT proof and checks the proof with drat-trim.

## Build

Linux or macOS, with gcc, g++ (C++17), make, and Python 3 with `python-sat` and `networkx` for the encoder and tools.

```
./build.sh
pip install python-sat networkx
```

`build.sh` builds the vendored CaDiCaL 2.1.3 and Edge Addition Planarity Suite 4.0.1 (see `NOTICE.md`), links `bin/bipsat2`, and compiles `bin/drat-trim`.

## Worked example: K7 ∨ I3

K7 joined to three mutually non-adjacent vertices is the ten-vertex graph behind the ten-vertex rule (a graph on ten vertices is biplanar exactly when its complement has two disjoint edges). It has 42 edges, well under Euler's 48, so only geometry excludes it.

```
cd examples/k7_join_i3
./run.sh
```

This encodes the four admissible splits (24/18 to 21/21) with all twin chains, refutes each with `bipsat2` (about 1 to 4 seconds each), and certifies each refutation by replay (CaDiCaL under 3 seconds, drat-trim under 5 seconds per split). Shipped lemma files and receipts with SHA256s are in `examples/k7_join_i3/instances` and `receipts`.

## Using it on your own graph

```
python3 encoder/encode.py graph.json --out work --twins all        # graph.json: {"n": N, "edges": [[a, b], ...]}
bin/bipsat2 work/graph_L45_38.inst --timeout 86400 --lemmas work/graph_L45_38.lem
python3 tools/replay.py work/graph_L45_38.inst work/graph_L45_38.lem   # after an UNSAT
```

A graph is non-biplanar when every admissible split is UNSAT; a SAT split prints the two layers, which are then checked from scratch by independent code before anyone believes them. `docs/FORMATS.md` has the instance and lemma formats, the solver options and exit codes.

## Where it has been used

The cloned-countries census: the 2,555 isomorphism classes of 28-vertex closed-twin doublings with independence number at most 3 (the fully twinned slice of the independence-counting route to a ten-chromatic biplanar graph), 2,543 decided, census data and status at https://sean.wiki/colorthecolonies/data/clone/index.html . The research ledger of the project, with the findings that document the solver (f127, f320, f468, f477, f487), is at https://sean.wiki/colorthecolonies/ .

## Provenance and licence

Developed in Sean Cook's Color the Colonies project by its AI research lanes, August to October 2026, after the design of Kirchweger, Scheucher and Szeider (SAT 2023). MIT licence; third-party components keep their own licences (`NOTICE.md`). Issues and pull requests welcome; for runs on specific graphs, open an issue with the edge list.
