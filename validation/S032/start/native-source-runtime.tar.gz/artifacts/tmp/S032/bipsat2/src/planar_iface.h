/* Minimal C interface over the edge-addition-planarity-suite,
   because the suite's headers are not C++-clean. */
#ifndef PLANAR_IFACE_H
#define PLANAR_IFACE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct PlanCtx PlanCtx;

/* Create a reusable checker for graphs on n vertices, up to max_edges edges. */
PlanCtx *plan_new (int n, int max_edges);
void plan_free (PlanCtx *ctx);

/* edges: 2*k ints (u0,v0,u1,v1,...), 0-based vertices.
   Returns 1 = planar, 0 = nonplanar (kur filled with 2*(*kur_len) ints, the
   Kuratowski subgraph's edges; kur must have room for 2*max_edges ints),
   -1 = internal error. */
int plan_check (PlanCtx *ctx, const int *edges, int k, int *kur, int *kur_len);

#ifdef __cplusplus
}
#endif
#endif
