#ifndef EMP_TIME_SHIM
#define EMP_TIME_SHIM
#include <time.h>
struct timeval { long long tv_sec; long tv_usec; };
static int gettimeofday(struct timeval *tv, void *unused) {
  struct timespec ts; (void)unused; timespec_get(&ts, TIME_UTC);
  tv->tv_sec = ts.tv_sec; tv->tv_usec = (long)(ts.tv_nsec / 1000); return 0;
}
#endif
