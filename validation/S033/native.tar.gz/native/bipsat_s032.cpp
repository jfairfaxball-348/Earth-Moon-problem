// bipsat2: SAT-modulo-planarity with OPTIONAL edges (fable-peony, 2026-09-01).
// Edge i of the candidate list has TWO variables: 2i+1 = present in layer 1,
// 2i+2 = present in layer 2 (both false = edge absent; both true allowed).
// Header: p bipsat2 <n> <m> <n_extra_vars> <n_extra_clauses>; extra clauses may
// use vars 2m+1 .. 2m+n_extra_vars.  Derived from bipsat.cpp:
//
// One boolean variable per edge of G (true = layer 1, false = layer 2).
// CaDiCaL 2.x ExternalPropagator (IPASIR-UP) watches the partial assignment;
// whenever a layer's currently-assigned edge set goes nonplanar, a Kuratowski
// subgraph is extracted (Boyer-Myrvold, edge-addition-planarity-suite) and its
// non-monochromatic clause is returned as an external clause. A full model is
// accepted only after both layers pass a from-scratch planarity check.
//
// Instance format (text):
//   p bipsat <n> <m> <n_extra_vars> <n_extra_clauses>
//   e <u> <v>            (m lines; edge i (0-based) <-> SAT var i+1; 0-based vertices)
//   <lit> ... 0          (n_extra_clauses DIMACS clauses; may use vars m+1..m+n_extra_vars)
//
// Output:
//   s SATISFIABLE / s UNSATISFIABLE / s UNKNOWN
//   on SAT: "L1 u-v ..." and "L2 u-v ..." lines with the verified split
//   stats lines prefixed "c "

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <vector>
#include <string>
#include <chrono>
#include <cerrno>
#include <cctype>
#include <fstream>
#include <filesystem>

#include "cadical.hpp"
#include "planar_iface.h"
#include "s032_subdivision.hpp"
#include <unistd.h>

static double now_s () {
  using namespace std::chrono;
  return duration<double> (steady_clock::now ().time_since_epoch ()).count ();
}

[[noreturn]] static void die (const char *msg) {
  fprintf (stderr, "bipsat FATAL: %s\n", msg);
  fflush (stderr);
  exit (3);
}

// ---------------------------------------------------------------------------
// Planarity checking with Kuratowski extraction
// ---------------------------------------------------------------------------

struct PlanarityChecker {
  PlanCtx *ctx = nullptr;
  int max_edges;
  std::vector<int> flat, kbuf;

  PlanarityChecker (int n_, int max_edges_) : max_edges (max_edges_) {
    ctx = plan_new (n_, max_edges_);
    if (!ctx) die ("plan_new failed");
    flat.reserve (2 * max_edges);
    kbuf.assign (2 * max_edges + 8, 0);
  }
  ~PlanarityChecker () { plan_free (ctx); }
  PlanarityChecker (const PlanarityChecker &) = delete;

  // Returns true if planar. If nonplanar, fills kur_edges with the
  // Kuratowski subgraph's edges (0-based vertex pairs, u < v).
  bool check (const std::vector<std::pair<int, int>> &edges,
              std::vector<std::pair<int, int>> &kur_edges) {
    flat.clear ();
    for (auto &e : edges) {
      flat.push_back (e.first);
      flat.push_back (e.second);
    }
    int klen = 0;
    int r = plan_check (ctx, flat.data (), (int) edges.size (), kbuf.data (),
                        &klen);
    if (r == 1) return true;
    if (r != 0) die ("plan_check internal error");
    kur_edges.clear ();
    for (int i = 0; i < klen; i++)
      kur_edges.emplace_back (kbuf[2 * i], kbuf[2 * i + 1]);
    return false;
  }
};

// Persisted lemmas are untrusted inputs, including after an interrupted write.
// Never add a literal until the ENTIRE clause has been parsed and its geometric
// meaning checked against this instance's edge map. Closing an EOF fragment with
// zero would strengthen a valid Kuratowski clause and can manufacture UNSAT.
struct LemmaLoadStats {
  long loaded = 0, rejected_format = 0, rejected_planar = 0, incomplete = 0;
  bool needs_separator = false;
};

static LemmaLoadStats load_validated_lemmas (
    const char *path, int n, const std::vector<std::pair<int, int>> &edges,
    CaDiCaL::Solver *solver, FILE *validated_out) {
  LemmaLoadStats stats;
  // DrvFS makes thousands of tiny file operations costly; buffer before open.
  std::vector<char> read_buffer (1 << 20);
  std::ifstream input;
  input.rdbuf ()->pubsetbuf (read_buffer.data (), read_buffer.size ());
  input.open (path);
  if (!input) return stats;  // a new run may have no lemma file yet
  const int m = (int) edges.size ();
  PlanarityChecker checker (n, m);
  std::vector<int> clause;
  std::vector<long> seen (m, 0);
  std::vector<std::pair<int, int>> support, kur;
  clause.reserve (m);
  support.reserve (m);
  std::string line;
  long line_number = 0;
  while (std::getline (input, line)) {
    ++line_number;
    stats.needs_separator = input.eof () && !line.empty ();
    clause.clear ();
    support.clear ();
    const char *p = line.c_str ();
    while (std::isspace ((unsigned char) *p)) ++p;
    if (!*p || *p == 'c') continue;
    bool malformed = false, terminated = false;
    int layer = -1;
    while (*p) {
      while (std::isspace ((unsigned char) *p)) ++p;
      if (!*p) break;
      char *end = nullptr;
      errno = 0;
      long lit = std::strtol (p, &end, 10);
      if (errno == ERANGE || end == p || (*end && !std::isspace ((unsigned char) *end))) {
        malformed = true;
        break;
      }
      p = end;
      if (lit == 0) {
        terminated = true;
        while (std::isspace ((unsigned char) *p)) ++p;
        if (*p) malformed = true;  // our writer emits one clause per line
        break;
      }
      // Generated theory clauses contain only negative presence literals from
      // one layer. Reject SAT auxiliaries, mixed layers, and duplicate edges.
      if (lit >= 0 || lit < -2L * m) { malformed = true; break; }
      int v = (int) -lit;
      int this_layer = (v - 1) & 1;
      int edge_index = (v - 1) / 2;
      if ((layer >= 0 && layer != this_layer) || seen[edge_index] == line_number) {
        malformed = true;
        break;
      }
      layer = this_layer;
      seen[edge_index] = line_number;
      clause.push_back ((int) lit);
      support.push_back (edges[edge_index]);
    }
    if (malformed) { ++stats.rejected_format; continue; }
    if (!terminated) { ++stats.incomplete; continue; }
    // Nonplanarity is sufficient; a subdivision need not be minimal. This also
    // detects stale, reordered, or foreign variable maps without trusting a hash.
    if (support.size () < 9 || checker.check (support, kur)) {
      ++stats.rejected_planar;
      continue;
    }
    if (solver) {
      for (int lit : clause) solver->add (lit);
      solver->add (0);
    }
    if (validated_out) {
      for (int lit : clause) fprintf (validated_out, "%d ", lit);
      fputs ("0\n", validated_out);
    }
    ++stats.loaded;
  }
  if (input.bad ()) die ("error reading lemma file");
  return stats;
}

// ---------------------------------------------------------------------------
// The propagator
// ---------------------------------------------------------------------------

struct BipPropagator : CaDiCaL::ExternalPropagator {
  int n, m;
  std::vector<std::pair<int, int>> edges; // edge index -> (u,v), 0-based
  std::vector<std::vector<int>> edge_var; // (u,v) -> var (1..m), 0 if absent

  // mirrored trail
  std::vector<int8_t> val;   // var -> {0 unassigned, +1 layer1, -1 layer2}
  std::vector<int> trail;    // assigned vars in order
  std::vector<size_t> level_marks;

  int cnt[2] = {0, 0};       // current edge count per layer (0 = L1/true, 1 = L2/false)
  bool dirty[2] = {false, false};
  bool conflict_outstanding = false;

  std::vector<std::vector<int>> pending; // external clauses waiting for delivery
  std::vector<int> deliver;              // clause being streamed out
  size_t deliver_pos = 0;

  PlanarityChecker checker;
  std::vector<std::pair<int, int>> scratch_edges, kur;

  // lemma persistence: every external clause is a permanently valid theory lemma,
  // so it is appended here as it is derived and reloaded on the next run.
  FILE *lemma_out = nullptr;
  std::vector<char> lemma_buffer;
  long n_lemmas_written = 0, n_lemmas_loaded = 0;

  void record_lemma (const std::vector<int> &clause) {
    if (!lemma_out) return;
    for (int lit : clause) fprintf (lemma_out, "%d ", lit);
    fputs ("0\n", lemma_out);
    ++n_lemmas_written;
    if (fflush(lemma_out)) die("S032 lemma flush failed");
  }

  // stats
  long n_checks = 0, n_nonplanar = 0, n_clauses_added = 0, n_model_checks = 0;
  long n_model_rejects = 0, n_renotify = 0;
  double check_time = 0.0;

  // last accepted model (the split)
  std::vector<int8_t> model_val;

  BipPropagator (int n_, int m_, const std::vector<std::pair<int, int>> &edges_)
      : n (n_), m (m_), edges (edges_), checker (n_, m_) {
    val.assign (2 * m + 1, 0);
    edge_var.assign (n, std::vector<int> (n, 0));
    for (int i = 0; i < m; i++) {
      auto [u, v] = edges[i];
      edge_var[u][v] = edge_var[v][u] = i + 1;
    }
  }

  ~BipPropagator () {
    // Enumeration can return before main's normal close. Flush while the
    // owned stdio buffer is still alive (before member destruction).
    if (lemma_out) fclose (lemma_out);
  }

  void collect_layer (int layer, std::vector<std::pair<int, int>> &out) {
    out.clear ();
    for (int i = 0; i < m; i++)
      if (val[2 * i + 1 + layer] > 0) out.push_back (edges[i]);
  }

  // Check one layer's current partial edge set; enqueue Kuratowski clause if bad.
  void check_layer (int layer) {
    double t0 = now_s ();
    collect_layer (layer, scratch_edges);
    n_checks++;
    bool planar = checker.check (scratch_edges, kur);
    check_time += now_s () - t0;
    dirty[layer] = false;
    if (planar) return;
    n_nonplanar++;
    std::vector<int> clause;
    clause.reserve (kur.size ());
    for (auto &e : kur) {
      int v = edge_var[e.first][e.second];
      if (!v) die ("Kuratowski edge not in G - impossible");
      clause.push_back (-(2 * (v - 1) + 1 + layer));
    }
    if (!s032_subdivision(n, kur)) die("S032 independent subdivision guard rejected certificate");
    record_lemma (clause);
    pending.push_back (std::move (clause));
    conflict_outstanding = true;
  }

  void maybe_check () {
    if (conflict_outstanding) return;
    for (int layer = 0; layer < 2; layer++)
      if (dirty[layer] && cnt[layer] >= 9) {
        check_layer (layer);
        if (conflict_outstanding) return;
      }
  }

  // ---- notifications ----

  void notify_assignment (const std::vector<int> &lits) override {
    for (int lit : lits) {
      int v = abs (lit);
      if (v > 2 * m) continue; // only edge vars are observed
      int8_t s = lit > 0 ? 1 : -1;
      if (val[v] == s) { n_renotify++; continue; }
      if (val[v] != 0) die ("contradictory re-notification without backtrack");
      val[v] = s;
      trail.push_back (v);
      if (s > 0) {
        int layer = (v - 1) & 1;
        cnt[layer]++;
        dirty[layer] = true;
      }
    }
    maybe_check ();
  }

  void notify_new_decision_level () override {
    level_marks.push_back (trail.size ());
  }

  void notify_backtrack (size_t new_level) override {
    if (new_level >= level_marks.size ()) return;
    size_t keep = level_marks[new_level];
    while (trail.size () > keep) {
      int v = trail.back ();
      trail.pop_back ();
      if (val[v] > 0) cnt[(v - 1) & 1]--;
      val[v] = 0;
    }
    level_marks.resize (new_level);
    conflict_outstanding = false;
    dirty[0] = dirty[1] = false; // removal cannot create nonplanarity
  }

  // ---- model check ----

  bool cb_check_found_model (const std::vector<int> &model) override {
    n_model_checks++;
    std::vector<int8_t> mv (2 * m + 1, 0);
    for (int lit : model) {
      int v = abs (lit);
      if (v <= 2 * m) mv[v] = lit > 0 ? 1 : -1;
    }
    for (int i = 1; i <= 2 * m; i++)
      if (!mv[i]) die ("model leaves an edge variable unassigned");
    for (int layer = 0; layer < 2; layer++) {
      scratch_edges.clear ();
      for (int i = 0; i < m; i++)
        if (mv[2 * i + 1 + layer] > 0) scratch_edges.push_back (edges[i]);
      double t0 = now_s ();
      n_checks++;
      bool planar = checker.check (scratch_edges, kur);
      check_time += now_s () - t0;
      if (!planar) {
        n_nonplanar++;
        n_model_rejects++;
        std::vector<int> clause;
        for (auto &e : kur) {
          int v = edge_var[e.first][e.second];
          if (!v) die ("Kuratowski edge not in G - impossible");
          clause.push_back (-(2 * (v - 1) + 1 + layer));
        }
        if (!s032_subdivision(n, kur)) die("S032 independent subdivision guard rejected certificate");
    record_lemma (clause);
        pending.push_back (std::move (clause));
        conflict_outstanding = true;
        return false;
      }
    }
    model_val = mv;
    return true;
  }

  // ---- external clause delivery ----

  bool cb_has_external_clause (bool &is_forgettable) override {
    is_forgettable = false;
    if (pending.empty ()) return false;
    deliver = std::move (pending.back ());
    pending.pop_back ();
    deliver_pos = 0;
    n_clauses_added++;
    return true;
  }

  int cb_add_external_clause_lit () override {
    if (deliver_pos < deliver.size ()) return deliver[deliver_pos++];
    if (pending.empty ()) conflict_outstanding = false;
    return 0;
  }

  int cb_decide () override { return 0; }
  int cb_propagate () override { return 0; }
  int cb_add_reason_clause_lit (int) override { return 0; }
};

// ---------------------------------------------------------------------------

struct WallTerminator : CaDiCaL::Terminator {
  double deadline, last = 0, start = now_s();
  BipPropagator *prop = nullptr; CaDiCaL::Solver *engine = nullptr;
  bool terminate () override {
    double t=now_s();
    if(t-last>=30 && prop) {
      printf("c S032_PROGRESS seconds=%.3f checks=%ld cuts=%ld model_checks=%ld check_seconds=%.3f\n",
        t-start,prop->n_checks,prop->n_lemmas_written,prop->n_model_checks,prop->check_time);
      if(engine) printf("c S032_LOGIC conflicts=%lld decisions=%lld propagations=%lld\n", (long long)engine->get_statistic_value("conflicts"), (long long)engine->get_statistic_value("decisions"), (long long)engine->get_statistic_value("propagations"));
      fflush(stdout);
      if(prop->lemma_out) {fflush(prop->lemma_out);fsync(fileno(prop->lemma_out));}
      last=t;
    }
    return t>deadline;
  }
};

int main (int argc, char **argv) {
  if (argc < 2) {
    fprintf (stderr, "usage: bipsat2 <instance> [--timeout SECONDS] [--lemmas FILE] "
                     "[--validate-lemmas-only] [--write-validated-lemmas FILE]\n");
    return 2;
  }
  double timeout = 0;
  int enumerate = 0, block_first = 0, block_count = 0;
  const char *lemma_path = nullptr;
  const char *validated_path = nullptr;
  bool validate_only = false;
  for (int i = 2; i < argc; i++) {
    if (!strcmp (argv[i], "--timeout") && i + 1 < argc) timeout = atof (argv[++i]);
    else if (!strcmp (argv[i], "--enumerate") && i + 1 < argc) enumerate = atoi (argv[++i]);
    else if (!strcmp (argv[i], "--block-vars") && i + 2 < argc) { block_first = atoi (argv[++i]); block_count = atoi (argv[++i]); }
    else if (!strcmp (argv[i], "--lemmas") && i + 1 < argc) lemma_path = argv[++i];
    else if (!strcmp (argv[i], "--validate-lemmas-only")) validate_only = true;
    else if (!strcmp (argv[i], "--write-validated-lemmas") && i + 1 < argc) validated_path = argv[++i];
  }
  if ((validate_only || validated_path) && !lemma_path)
    die ("lemma validation requires --lemmas FILE");
  if (validated_path &&
      (std::filesystem::weakly_canonical (lemma_path) == std::filesystem::weakly_canonical (validated_path) ||
       (std::filesystem::exists (lemma_path) && std::filesystem::exists (validated_path) &&
        std::filesystem::equivalent (lemma_path, validated_path))))
    die ("validated lemma output must differ from input");

  FILE *f = fopen (argv[1], "r");
  if (!f) die ("cannot open instance file");
  int n, m, extra_vars, extra_clauses;
  if (fscanf (f, "p bipsat2 %d %d %d %d", &n, &m, &extra_vars, &extra_clauses) != 4)
    die ("bad instance header");
  std::vector<std::pair<int, int>> edges;
  for (int i = 0; i < m; i++) {
    int u, v;
    if (fscanf (f, " e %d %d", &u, &v) != 2) die ("bad edge line");
    if (u == v || u < 0 || v < 0 || u >= n || v >= n) die ("bad edge endpoints");
    if (u > v) std::swap (u, v);
    edges.emplace_back (u, v);
  }

  CaDiCaL::Solver solver;
  BipPropagator prop (n, m, edges);
  solver.connect_external_propagator (&prop);
  solver.resize (2 * m + extra_vars);
  for (int v = 1; v <= 2 * m; v++) solver.add_observed_var (v);

  // extra clauses (cardinality encodings, symmetry units)
  for (int c = 0; c < extra_clauses; c++) {
    int lit;
    do {
      if (fscanf (f, " %d", &lit) != 1) die ("bad clause literal");
      if (!validate_only) solver.add (lit);
    } while (lit);
  }
  fclose (f);

  if (lemma_path) {
    std::vector<char> validated_buffer (1 << 20);
    FILE *validated_out = validated_path ? fopen (validated_path, "w") : nullptr;
    if (validated_path && !validated_out) die ("cannot open validated lemma output");
    if (validated_out) setvbuf (validated_out, validated_buffer.data (), _IOFBF, validated_buffer.size ());
    double validation_start = now_s ();
    LemmaLoadStats loaded = load_validated_lemmas (
        lemma_path, n, edges, validate_only ? nullptr : &solver, validated_out);
    if (validated_out && (fflush (validated_out) || fclose (validated_out)))
      die ("error writing validated lemma output");
    prop.n_lemmas_loaded = loaded.loaded;
    printf ("c loaded %ld lemma(s) from %s\n", loaded.loaded, lemma_path);
    printf ("c lemma_validation loaded=%ld rejected_format=%ld rejected_planar=%ld "
            "incomplete=%ld seconds=%.3f\n", loaded.loaded, loaded.rejected_format,
            loaded.rejected_planar, loaded.incomplete, now_s () - validation_start);
    fflush (stdout);
    if (validate_only) {
      printf ("c lemma validation only: no solve and no input modification\n");
      return 0;
    }
    prop.lemma_out = fopen (lemma_path, "a");
    if (!prop.lemma_out) die ("cannot open the lemma file for appending");
    prop.lemma_buffer.resize (1 << 20);
    setvbuf (prop.lemma_out, prop.lemma_buffer.data (), _IOFBF, prop.lemma_buffer.size ());
    // Preserve damaged evidence, but isolate its last partial line so that a
    // future valid clause cannot concatenate with an incomplete integer token.
    if (loaded.needs_separator) {
      fputc ('\n', prop.lemma_out);
      fflush (prop.lemma_out);
    }
  }

  WallTerminator term; term.prop = &prop; term.engine = &solver;
  if (timeout > 0) {
    term.deadline = now_s () + timeout;
    solver.connect_terminator (&term);
  }

  double t0 = now_s ();
  int res = solver.solve ();
  printf("c S032_LOGIC conflicts=%lld decisions=%lld propagations=%lld\n", (long long)solver.get_statistic_value("conflicts"), (long long)solver.get_statistic_value("decisions"), (long long)solver.get_statistic_value("propagations"));
  double elapsed = now_s () - t0;
  if (enumerate || block_first || block_count) die("S032 enumeration forbidden");
  if (false) {
    // enumeration: print each model's split, block its union pattern, continue
    int found = 0;
    while (res == 10 && found < enumerate) {
      found++;
      std::vector<std::pair<int, int>> l1, l2;
      for (int i = 0; i < m; i++) {
        if (prop.model_val[2 * i + 1] > 0) l1.push_back (edges[i]);
        if (prop.model_val[2 * i + 2] > 0) l2.push_back (edges[i]);
      }
      printf ("m %d %.1f L1", found, now_s () - t0);
      for (auto &e : l1) printf (" %d-%d", e.first, e.second);
      printf (" L2");
      for (auto &e : l2) printf (" %d-%d", e.first, e.second);
      putchar (10);
      // the blocked variables (e.g. the core edge set) as a bit string, before the clause is added
      printf ("B %d ", found);
      for (int v = block_first; v < block_first + block_count; v++) putchar (solver.val (v) > 0 ? '1' : '0');
      putchar (10);
      fflush (stdout);
      std::vector<int> blk;
      for (int v = block_first; v < block_first + block_count; v++)
        blk.push_back (solver.val (v) > 0 ? -v : v);
      for (int lit : blk) solver.add (lit);
      solver.add (0);
      if (found < enumerate) res = solver.solve ();
    }
    elapsed = now_s () - t0;
    printf ("c enumerated=%d last_res=%d", found, res); putchar (10);
    if (found > 0) { printf ("s SATISFIABLE"); putchar (10); printf ("c enumeration ended with %s", res == 20 ? "UNSAT (complete)" : res == 10 ? "cap reached" : "UNKNOWN (timeout)"); putchar (10); fflush (stdout); return 10; }
  }

  printf ("c n=%d m=%d extra_vars=%d extra_clauses=%d\n", n, m, extra_vars,
          extra_clauses);
  printf ("c checks=%ld nonplanar=%ld clauses_added=%ld model_checks=%ld "
          "model_rejects=%ld renotify=%ld\n",
          prop.n_checks, prop.n_nonplanar, prop.n_clauses_added,
          prop.n_model_checks, prop.n_model_rejects, prop.n_renotify);
  printf ("c check_time=%.3f solve_time=%.3f\n", prop.check_time, elapsed);
  if (lemma_path) {
    printf ("c lemmas loaded=%ld written=%ld\n", prop.n_lemmas_loaded, prop.n_lemmas_written);
    fflush (prop.lemma_out);
    fclose (prop.lemma_out);
    prop.lemma_out = nullptr;
  }

  if (res == 10) {
    // Final belt-and-braces verification of the stored model.
    if ((int) prop.model_val.size () != 2 * m + 1) die ("SAT but no stored model");
    std::vector<std::pair<int, int>> l1, l2, kur;
    for (int i = 0; i < m; i++) {
      if (prop.model_val[2 * i + 1] > 0) l1.push_back (edges[i]);
      if (prop.model_val[2 * i + 2] > 0) l2.push_back (edges[i]);
    }
    PlanarityChecker fresh (n, m);
    if (!fresh.check (l1, kur)) die ("SAT model layer 1 NOT planar on recheck");
    if (!fresh.check (l2, kur)) die ("SAT model layer 2 NOT planar on recheck");
    printf ("s SATISFIABLE\n");
    for(int v=1;v<=2*m+extra_vars;v++) {
      if((v-1)%20==0) printf("v ");
      int value=solver.val(v);printf("%d ",value==0?-v:value);
      if(v%20==0 || v==2*m+extra_vars) printf("0\n");
    }
    printf ("L1");
    for (auto &e : l1) printf (" %d-%d", e.first, e.second);
    printf ("\nL2");
    for (auto &e : l2) printf (" %d-%d", e.first, e.second);
    printf ("\n");
  } else if (res == 20) {
    printf ("s UNSATISFIABLE\n");
  } else {
    printf ("s UNKNOWN\n");
  }
  fflush (stdout);
  return res == 10 ? 10 : res == 20 ? 20 : 0;
}
